#!/usr/bin/env python3
from path_finder import get_path
# from pather import get_path
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
# import json
import numpy as np
import time
from nav_msgs.msg import Odometry

class TurtlebotOpenLoopController(Node):
    def __init__(self, linear_scale_factor=10, angular_scale_factor=10):
        super().__init__('turtlebot_open_loop_controller')
        self.publisher_ = self.create_publisher(Twist, 'cmd_vel', 10)
        self.path_and_rpms = get_path()
        self.x=0
        self.y=0
        self.z_ang=0
        self.i = 0
        self.subscription = self.create_subscription(
            Odometry,
            'odom',
            self.odom_callback,
            10)
        self.subscription

    def execute_path(self):

        if self.i >= len(self.path_and_rpms)-1:
            self.send_velocity_command(0.0, 0.0)
            self.get_logger().info("Finished navigation.",once=True)
            return None
        else:
            pos,rpms = self.path_and_rpms[self.i][0],self.path_and_rpms[self.i][1]
            pos_x = pos[0]
            pos_y = pos[1]
            angular_vel = 0
            linear_vel = 20*2*np.pi*0.033/60
            req_angle = np.arctan2(pos_y-self.y,pos_x-self.x)
            dist = np.sqrt(np.square(pos_y-self.y)+np.square(pos_x-self.x))
            e = 0
            if dist > 0.15:
                e = req_angle-self.z_ang
                angular_vel = 0.4*e
                if angular_vel < -1.5:
                    angular_vel = -1.5
                elif angular_vel > 1.5:
                    angular_vel = 1.5
                self.get_logger().info(f'distance : {dist}')
                self.send_velocity_command(linear_vel, angular_vel)
                time.sleep(0.5)
                dist = np.sqrt(np.square(pos_y-self.y)+np.square(pos_x-self.x))
            else:
                self.i += 1


    def odom_callback(self, msg):

        position = msg.pose.pose.position
        orientation = msg.pose.pose.orientation
        self.x = position.x
        self.y = position.y
        self.z_ang = np.arctan2(2*(orientation.w*orientation.z+orientation.x*orientation.y),(1-2*(np.square(orientation.y)+np.square(orientation.z))))
        self.execute_path()

    def send_velocity_command(self, linear_vel, angular_vel):
        msg = Twist()
        msg.linear.x = linear_vel
        msg.angular.z = float(angular_vel)
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = TurtlebotOpenLoopController(linear_scale_factor=10, angular_scale_factor=10)
    
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
